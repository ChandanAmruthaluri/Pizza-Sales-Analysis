SELECT * FROM my_portfolio.pizza_sales;

# Total Revenue : 
select sum(total_price) from pizza_sales;

# Average order value :
Select (sum(total_price)/ count(DISTINCT order_id)) as Avg_order_value
from pizza_sales;

# Total Pizzas Sold :
select sum(quantity) as pizza_Sales
from pizza_Sales;

# Total Orders :
select count(DISTINCT order_id) as Total_orders
from pizza_sales;

# Average pizzas per order :
select 
cast(cast(sum(quantity) AS DECIMAL(10, 2)) / 
cast(count(distinct	order_id) as DECIMAL(10, 2)) AS DECIMAL(10,2)) AS Avg_pizzas_per_order
from pizza_Sales;

# Daily Trend for total Orders :
select DAYNAME(str_to_date(order_date, '%d-%m-%Y')) as order_day,
count(DISTINCT order_id) as total_orders
from pizza_sales
group by DAYNAME(str_to_date(order_date, '%d-%m-%Y'));

#Monthly trend for Orders :
select monthname(str_to_date(order_date, '%d-%m-%Y')) as Month_name,
count(DISTINCT order_id) as Total_orders
from pizza_sales
group by monthname(str_to_date(order_date, '%d-%m-%Y'));

# % of Sales by Pizza Category :
select pizza_category, Cast(sum(total_price) as decimal(10,2)) as total_revenue,
cast(sum(total_price) * 100/(select sum(total_price) from pizza_sales) AS decimal(10,2)) as PCT
from pizza_sales
group by pizza_category;

# % of sales by pizza size :
select pizza_size, Cast(sum(total_price) as decimal(10,2)) as total_revenue,
cast(sum(total_price) * 100/(select sum(total_price) from pizza_sales) AS decimal(10,2)) as PCT
from pizza_sales
group by pizza_size;

# Total Pizzas sold by pizza category :
select pizza_category, sum(quantity) as Total_quantity_sold
from pizza_sales
group by pizza_category;

# Top 5 Pizzas by revenue :
select pizza_name, sum(total_price) as total_revenue
from pizza_sales
group by pizza_name
order by total_revenue DESC
limit 5 offset 0;

# Bottom 5 Pizzas by revenue :
select pizza_name, sum(total_price) as total_revenue
from pizza_sales
group by pizza_name
order by total_revenue ASC
limit 5 offset 0;

# Top 5 Pizzas by revenue :
select pizza_name, sum(quantity) as total_pizza_sold
from pizza_sales
group by pizza_name
order by total_pizza_sold DESC
limit 5 offset 0;

# Bottom 5 Pizzas by revenue :
select pizza_name, sum(quantity) as total_pizza_sold
from pizza_sales
group by pizza_name
order by total_pizza_sold ASC
limit 5 offset 0;

# Top 5 Pizzas by Total Orders :
select pizza_name, count(DISTINCT order_id) as total_orders
from pizza_sales
group by pizza_name
order by total_orders DESC
limit 5 offset 0;

# Top 5 Pizzas by Total Orders :
select pizza_name, count(DISTINCT order_id) as total_orders
from pizza_sales
group by pizza_name
order by total_orders ASC
limit 5 offset 0;

